const axios = require('axios');

axios.get('https://api.spotify.com/v1/search?q=ere&type=track', {
    headers: {
    'Authorization': 'Bearer BQBgR7oVc7_Ci4G4X4wTUKrcEWwWMswSR80RtM1D_Papy1C6E9iCWKOiWcAiK53zqlBMk7UKU655LPCgYUNLehw843S1K6pty34oyrueC9X0tW6s3SKQKeGJPuRogSdmiQpJn5l8gJ5D0dahl55COwWnjSFfmXopytjbKpRW5C4SPk4Vg9H3Y0cVPBqWH0etm8LgcUNLLG-rWYdo3v4'
}
}).then((data)=>{
    console.log(data.data.tracks.items[0].id);
})

